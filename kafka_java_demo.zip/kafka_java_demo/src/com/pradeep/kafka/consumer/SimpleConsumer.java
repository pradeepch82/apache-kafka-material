package com.pradeep.kafka.consumer;
import java.util.Arrays;
import java.util.Properties;
import java.util.function.Supplier;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class SimpleConsumer{

    public static void main(String[] args) throws Exception{

        String topicName = "AtosTopic";
        String groupName = "SupplierTopicGroup";

        Properties props = new Properties();
        //props.put("bootstrap.servers", "localhost:9092,localhost:9093,localhost:9094");
        props.put("bootstrap.servers", "localhost:9092");
        props.put("group.id", groupName);
        
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer","org.apache.kafka.common.serialization.StringDeserializer");
       
        
        props.put("enable.auto.commit", "true");

        KafkaConsumer<String, String> consumer = null;

        try {
        	consumer = new KafkaConsumer<String, String>(props);
        	      
        	      //Kafka Consumer subscribes list of topics here.
        	      consumer.subscribe(Arrays.asList(topicName));
        	      
        	      //print the topic name
        	      System.out.println("Subscribed to topic " + topicName);
        	      int i = 0;
        	      
        	      while (true) {
        	    	ConsumerRecords<String, String> records = consumer.poll(100);
                 	   
        	    	 System.out.println("making reequest to topic :");
        	         for (ConsumerRecord<String, String> record : records)
        	         
        	         // print the offset,key and value for the consumer records.
        	         System.out.printf("offset = %d, key = %s, value = %s\n", 
        	            record.offset(), record.key(), record.value());
        	      }
        	      
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            
        //	consumer.commitAsync();
                  	
            consumer.close();
        }
    }
}
